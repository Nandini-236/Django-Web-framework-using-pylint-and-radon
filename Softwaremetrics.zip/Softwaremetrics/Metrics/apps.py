from django.apps import AppConfig


class MetricsConfig(AppConfig):
    name = 'Metrics'
