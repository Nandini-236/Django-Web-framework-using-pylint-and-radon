cars = [123, "Volvo", "BMW"]
print(cars)
#for x in cars:
  #print(x)
